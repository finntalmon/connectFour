public class Human extends Player{

    public Human(String name, String token) {
        super(name, token);
    }

}